// import React from 'react'

// const SignUp = () => {
//   return (
//     <div>SignUp</div>
//   )
// }

// export default SignUp
// Signup.js
import React, { useState } from 'react';
import api from './api';

const Signup = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSignup = async () => {
    try {
      const response = await api.post('/users', { username, password });
      console.log('Signup Successful:', response.data);
    } catch (error) {
      console.error('Signup Failed:', error.message);
    }
  };

  return (
    <div>
      <h2>Signup</h2>
      <input
        type="text"
        placeholder="Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button onClick={handleSignup}>Signup</button>
    </div>
  );
};

export default Signup;
