import { fetchCVs } from "./Axios";

import React, { useEffect, useState } from 'react'



const AxiosResponseData = () => {
   const [Cvs,setCvs] =useState([]);
    // const dispatch=useDispatch();
    const fetchData = async () => {
        const CVData = await fetchCVs();
            setCvs(CVData);
        
        
            
            
    }
        
        useEffect(() => {
               
            fetchData();
            // toast.success("Cvs have been fetched");
            console.log("Cvs",Cvs)
        }, []);
            
        // const {Products}=useSelector((state)=>state.allCart);
        
  return (
    <div className="container">
       <h3>Cvs data</h3>
    </div>
  )
}

export default AxiosResponseData;

// const express = require('express');
// const cors = require('cors');
// const axios = require('axios');

// const app = express();
// const port = 3001;

// app.use(cors());

// app.get('/fetchCVs', async (req, res) => {
//   try {
//     const response = await axios.get('https://www.canva.com/templates/?query=resume');
//     res.json(response.data);
//   } catch (error) {
//     console.error('Error fetching CVs:', error);
//     res.status(500).send('Internal Server Error');
//   }
// });

// app.listen(port, () => {
//   console.log(`Server is running on port ${port}`);
// });
