// import axios from "axios";


// const fetchResumesData = () => {
  
//     return axios.get('https://www.canva.com/templates/?query=resume');
// }

// export const fetchCVs = async () => {
//     try {
//         const response = await fetchResumesData();
//         if (response && response.data && Array.isArray(response.data)) {
//             return response.data;
//         } else {
//             console.error('Invalid or empty data received:', response.data);
//             return [];
//         }
//     } catch (error) {
//         console.error('Request Error:', error);
//         return [];
//     }
// };
// // ;

// api.js
import axios from 'axios';

const baseURL = 'https://jsonplaceholder.typicode.com';

const api = axios.create({
  baseURL,
});

export const setAuthToken = (token) => {
  if (token) {
    api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
  } else {
    delete api.defaults.headers.common['Authorization'];
  }
};

export default api;
