import '/node_modules/bootstrap/dist/css/bootstrap.min.css';
import '/node_modules/bootstrap/dist/js/bootstrap.bundle.js';
import './App.css';
import AppRoutes from './Routes/AppRoutes';

const App=()=> {
  return (
   
    <>
    <AppRoutes />
    
   </>
  );
}

export default App;


