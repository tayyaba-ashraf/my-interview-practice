import React from 'react'
import HomeBanner from './HomeBanner'
import AxiosResponseData from '../../Axios/AxiosResponseData'


const Home = () => {
  return (
    <>
    <HomeBanner />
    
    </>
  )
}

export default Home