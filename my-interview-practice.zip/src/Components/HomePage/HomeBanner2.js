import React from 'react'

const HomeBanner2 = () => {
  return (
    <div>
        <div className="rdHmInner">
        <div className="rdHmDesc">
          <h1>Master the interview & land a job worth loving.</h1>
          <p>
            Simulate realistic interviews for over 120 different job positions and level up your skills in no time.
          </p>
          <a href="https://myinterviewpractice.com/pricing/#table" className="ndBtn">
            Learn More
          </a>
        </div>
        <div className="rdHmImg">
          <img
            className="lozad"
            data-src="/images/hmBannerImg.webp"
            alt=""
            src="/images/hmBannerImg.webp"
            data-loaded="true"
          />
        </div>
      </div>

      <div className="rdHmSec" style={{ background: 'url("/images/rdHmSecShade.webp") bottom center no-repeat', backgroundSize: 'cover' }}>
        <div className="container" style={{ maxWidth: '940px' }}>
          <div className="rdHmInner">
            <div className="rdHmImg">
              <img
                className="lozad"
                data-src="/images/rdHmSecImg.webp"
                alt=""
                src="/images/rdHmSecImg.webp"
                data-loaded="true"
              />
              <img
                className="rdmSecImg lozad"
                data-src="/images/rdHmSecImgMobile.webp"
                alt=""
                style={{ display: 'none' }}
              />
            </div>
            <div className="rdHmDesc">
              <h3 className="tpBar">Take Mock Interviews On Your Own</h3>
              <p>Take unlimited interviews and master your skills from anywhere. No awkward meetups required.</p>
            </div>
          </div>
        </div>
      </div>

      <div className="rdHm rdHmTwo">
       <div className="rdHmSecTwo">
          <div className="container" style={{ maxWidth: '940px' }}>
           <div className="rdHmInner">
             <div className="rdHmDesc">
               <h3 className="tpBar">Practice for the Pressure</h3>
               <p>We use your built-in camera to recreate the pressure of actual interviews so you can gain realistic experience and feel prepared for anything.</p>
             </div>
             <div className="rdHmImg">
               <img className="lozad" data-src="/images/rdHmSecTwoImg.webp" alt=""
                src="/images/rdHmSecTwoImg.webp" data-loaded="true" />
             </div>
         </div>
         </div>
       </div>
      </div>

      <div className="rdHmSec rdHmSecThree">
        <div className="container" style={{ maxWidth: '940px' }}>
           <div className="rdHmInner" style={{ justifyContent: 'flex-start' }}>
             <div className="rdHmImg">
               <img className="lozad" data-src="/images/rdHmSecThreeImg.webp" 
               alt="" src="/images/rdHmSecThreeImg.webp" data-loaded="true" />
             </div>
             <div className="rdHmDesc">
               <h3 className="tpBar">Review Your Recorded Responses</h3>
               <p>Your responses are automatically recorded, so you can watch them after your interview and know exactly how you came across.</p>
               <a href="https://myinterviewpractice.com/register-one/" className="ndBtn">Get Started</a>
             </div>
           </div>
        </div>
     </div>
     <div className="rdOptSec">
       <div className="container" style={{ maxWidth: '750px' }}>
       <div className="row">
          <div className="col-lg-6 col-md-6 col-sm-6">
            <div className="rdOptBlock">
              <img className="lozad" data-src="https://myinterviewpractice.com/images/build-interview-confidence.svg" alt=""
                src="https://myinterviewpractice.com/images/build-interview-confidence.svg" data-loaded="true" />
              <h3>Build interview confidence.</h3>
              <p>We give you everything you need to master your interview skills in less time than any other option, so you can walk into your interview with confidence.</p>
            </div>
          </div>
          <div className="col-lg-6 col-md-6 col-sm-6">
            <div className="rdOptBlock">
              <img className="lozad" data-src="/images/get-hired-faster.svg" alt=""
                src="/images/get-hired-faster.svg" data-loaded="true" />
              <h3>Get hired faster.</h3>
              <p>Our simulator is optimized to help you master your interview skills in the most efficient way possible, so you can be prepared to ace the interview in no time.</p>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-lg-6 col-md-6 col-sm-6">
            <div className="rdOptBlock">
              <img className="lozad" data-src="/images/earn-more.svg" alt=""
                src="/images/earn-more.svg" data-loaded="true" />
              <h3>Accelerate your career & earn more.</h3>
              <p>Master the skill of interviewing by practicing it just like you practice your trade and give your career a boost.</p>
            </div>
          </div>
          <div className="col-lg-6 col-md-6 col-sm-6">
            <div className="rdOptBlock">
              <img className="lozad" data-src="/images/land-the-job.svg" alt=""
                src="/images/land-the-job.svg" data-loaded="true" />
              <h3>Land the job you've been dreaming of.</h3>
              <p>Gain realistic interview experience and master 
                the skills you need to wow your employers and beat out the competition.</p>
            </div>
          </div>
        </div>

       </div>
     </div>
     <div className="trainingVdoSec">
     <div className="container">
     <div className="row">
     <div className="col-md-8 col-sm-7 col-12 vdoDisplay">
     {/* <div id="video_wrap" className="video_wrap">
              <div id="video_loader" className="loding_block" style={{ display: 'none' }}>
                <div className="newLoader">
                  <svg width="84px" height="84px" viewBox="0 0 84 84" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink">
                    
                  </svg>
                </div>
              </div>
              <div className="playback-animation" id="playback-animation">
                <svg className="playback-icons">
                  <use className="hidden" href="#play-icon"></use>
                  <use href="#pause"></use>
                </svg>
              </div>
              <video playsInline crossOrigin="anonymous" id="video" preload="auto" className="myVideo cueNone" poster="https://myinterviewpractice.com/images/video_poster/introduction.png" src="blob:https://myinterviewpractice.com/02e5cbc1-9458-4ae7-8b0c-8f2549a686a8">
                <track id="sourceTrack" label="English" kind="captions" srcLang="en-us" default="" />
              </video>
              <div className="vdoOverlay"></div>
              <div id="vdoCtrlOvrly" style={{ cursor: 'inherit' }}></div>
              <div className="sheetWrap hide">
                <h4>Explore the Full Training Program</h4>
                <p>Learn how to ace the interview with our complete online video course, extensive online guides and worksheets.</p>
                <a className="tSignup" href="https://myinterviewpractice.com/training/">Learn More</a>
              </div>
              <div id="video-controls" className="control">
                <div className="btmControl">
                  <div className="progress-bar">
                    <div id="progress" className="progress">
                      <span className="bufferBar" style={{ width: '19.1968%' }}></span>
                      <span className="timeBar"></span>
                    </div>
                  </div>
                  <div className="cntrlPart">
                    <div className="cntrlPartTp">
                      <div className="btnPlay btn" title="Play/Pause video"></div>
                      <div className="sound sound2 btn" title="Mute/Unmute sound"></div>
                      <div className="vol">
                        <div className="volume" title="Set volume">
                          <span className="volumeBar" style={{ width: '100%' }}></span>
                        </div>
                      </div>
                    </div>
                    <div className="cntrlPartBtm">
                      <div className="current">00:00</div> / <div className="duration">02:46</div>
                    </div>
                  </div>
                  <div className="btnCC btn cc-button cc_off" data-title="Closed Captions" id="cc-button">
                    <img src="https://myinterviewpractice.com/images/closed-caption-subtitles.svg" alt="Closed Captions" />
                  </div>
                  <div className="btnFS btn fullScreen" title="Switch to full screen">
                    <img src="https://myinterviewpractice.com/images/fullscreen_icon.svg" alt="Full Screen" />
                  </div>
                </div>
              </div>
            </div> */}


 ) 
}



<div class="careerAdvisorSec">
<div class="container" style="max-width: 940px;">
<div class="advisorContent">
<h4>For Career Advisors</h4>
<h3>Mock Interviews They Can Take on Their Own</h3>
<p>Provide simulated interviews they can conduct on their own. No need to schedule, commute, or meet in person.</p>
<a href="https://myinterviewpractice.com/enterprise/" class="ndBtn">Learn More</a>
</div>
<img class="lozad" data-src="https://myinterviewpractice.com/images/career-advisor.webp" alt="" />
</div>
</div>